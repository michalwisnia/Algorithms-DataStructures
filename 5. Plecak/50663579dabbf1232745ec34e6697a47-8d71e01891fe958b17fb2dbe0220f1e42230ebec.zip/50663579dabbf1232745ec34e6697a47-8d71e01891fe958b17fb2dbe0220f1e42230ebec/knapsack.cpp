#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <random>

std::mt19937 gen{std::random_device{}()};
template<typename T>
inline T random(T min, T max) { return std::uniform_int_distribution<T>{min, max}(gen); }

std::pair<std::vector<int>, std::vector<int>> generate(int size, int max_weight)
{
    std::vector<int> weight(size);
    std::vector<int> worth(size);

    for (--size; size >= 0; --size)
    {
        weight[size] = random(1,max_weight / 2);
        worth[size] = random(1,max_weight * 2);
    }

    return std::make_pair(weight, worth);
}

std::vector<int> knapsack_dynamic(const std::vector<int>& weight, const std::vector<int>& worth, int max_weight)
{
    int s = weight.size() + 1;
    int w = max_weight + 1;
    auto tab = new int*[s];
    for (int i = 0; i < s; ++i) {
        tab[i] = new int[w]{0};
        if (i > 0)
            for (int j = 0; j < w; ++j)
            {
                if (weight[i - 1] <= j)
                    tab[i][j] = std::max({tab[i-1][j], tab[i - 1][j - weight[i - 1]] + worth[i - 1]});
                else
                    tab[i][j] = tab[i - 1][j];
            }
    }
    
    /*
    for (int i = 0; i < s; ++i) {
        for (int j = 0; j < w; ++j)
            std::cout << tab[i][j] << " ";
        std::cout << std::endl;
    }
    */

    std::vector<int> out;
    out.reserve(s - 1);
    int max, maxi, maxj;
    do {
        max = maxi = maxj = 0;
        for (int i = 0; i < s; ++i)
            for (int j = 0; j < w; ++j) {
                if (tab[i][j] > max) {
                    max = tab[i][j];
                    maxi = i;
                    maxj = j;
                }
            }

        if (max > 0 )
        {
            out.push_back(maxi - 1);
            s = maxi;
            w = maxj - weight[maxi - 1] + 1;
        }

    } while (max != 0);


    return out;
}

template <class T>
void print(std::vector<T> in)
{
    for (const auto &item : in) {
        std::cout << item << " ";
    }
    std::cout << std::endl;
}


int main() {
    auto gen = generate(10, 15);
    print(gen.first);
    print(gen.second);
    auto result = knapsack_dynamic(gen.first, gen.second, 15);
    print(result);
    return 0;
}

