#include <iostream>
#include <random>

std::mt19937 gen{std::random_device{}()};

void printGraph(bool**in, int size)
{
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j)
            std::cout << in[i][j] << " ";
        std::cout << std::endl;
    }
}

void printGraph(int**in, int size)
{
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j)
            std::cout << in[i][j] << " ";
        std::cout << std::endl;
    }
}

void printGraph(std::vector<int>* in, int size)
{
    for (int i = 0; i < size; ++i) {
        for (auto a: in[i])
            std::cout << a << " ";
        std::cout << std::endl;
    }
}

template<typename T>
T random(T min, T max) {
    return std::uniform_int_distribution<T>{min, max}(gen);
}

bool** generateStandardGraph(int size, float density = 0.6)
{
    auto tab = new bool*[size];
    for (int i = 0; i < size; ++i) {
        tab[i] = new bool[size]{false};
    }


    for (int i = 1; i < size; ++i) {
        tab[i][i-1] = true;
        tab[i-1][i] = true;
    }

    int edges = size - 1;
    const int target = size * (size - 1) / 2 * density;

    int v1, v2;
    while (edges < target)
    {
        v1 = random(0, size-1);
        v2 = random(0, size-1);

        if (v1 == v2)
            continue;

        if (tab[v1][v2])
            continue;

        tab[v1][v2] = true;
        tab[v2][v1] = true;
        ++edges;
    }

    return tab;
}

int** generateWageGraph(int size, float density = 0.6)
{
    auto tab = generateStandardGraph(size, density);

    auto out = new int*[size];
    for (int i = 0; i < size; ++i) {
        out[i] = new int[size]{0};
    }

    for (int i = 0; i < size; ++i)
        for (int j = 0; j <= i; ++j)
            if (tab[i][j])
                out[i][j] = out[j][i] = random(0, 1000);
    return out;
}

bool** generateDirectedGraph(int size, float density = 0.6)
{
    auto tab = generateStandardGraph(size, density);
    for (int i = 0; i < size; ++i)
        for (int j = 0; j <= i; ++j)
            tab[i][j] = false;

    int v1, v2;
    for (int i = 0; i < size; ++i)
    {
        v1 = random(0, size - 1);
        v2 = random(0, size - 1);

        if (v1 == v2)
            continue;

        for (int j = 0; j < size; ++j){
            std::swap(tab[v1][j], tab[v2][j]);
        }

        for (int j = 0; j < size; ++j){
            std::swap(tab[j][v1], tab[j][v2]);
        }
    }
    return tab;
}


std::vector<int>* convert(bool** in, int size)
{
    auto* tab = new std::vector<int>[size];
    for (int i = 0; i < size; ++i)
        for (int j = 0; j < size; ++j)
            if (in[i][j])
                tab[i].push_back(j);
    return tab;
}

void _topologicalSort(std::vector<int>::iterator& iter, std::vector<int>* tab, bool* visited, int vertex)
{
    if (visited[vertex])
        return;

    visited[vertex] = true;
    *(iter++) = vertex;
    for (auto& a : tab[vertex])
        if (!visited[a])
            _topologicalSort(iter, tab, visited, a);
}

std::vector<int> topologicalSort(std::vector<int>* tab, int size)
{
    auto visited = new bool[size]{false};
    std::vector<int> out(size);
    int i = 0;
    auto iter = out.begin();
    while (iter != out.end())
        _topologicalSort(iter, tab, visited, i++);
    return out;
}

int main() {
    const int size = 8;
    auto tab = convert(generateDirectedGraph(size), size);
    printGraph(tab, size);
    auto sorted = topologicalSort(tab, size);
    for (const auto &item : sorted) {
        std::cout << item << " ";
    }
    std::cout << std::endl;

    auto a = generateWageGraph(size);
    printGraph(a, size);
    return 0;
}