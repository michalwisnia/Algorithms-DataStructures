#include <iostream>
#include <vector>
#include "OWL.h"
#include "BST.h"
#include <algorithm>
#include <random>


std::random_device rd;
std::mt19937 g(rd());

std::vector<int> getData(unsigned int size)
{
    std::vector<int> out(size);
    for (int & i : out)
        i = size--;
    std::shuffle(out.begin(), out.end(), g);
    return out;
} 

int main() 
{
    BST bst;
    std::vector<int> data = getData(100);
    bst.buildBST(data);
    bst.printInorder();
    return 0;
}
